
import { SilkClient } from "../index.js";

async function run() {
  const silk = new SilkClient("http://localhost:4200");
  console.log("Alice balance (before):", await silk.balance("alice"));
  const esc = await silk.createEscrow("escrow-1", "alice", "bob", 250);
  console.log("Created escrow:", esc);
  const rel = await silk.releaseEscrow("escrow-1");
  console.log("Released escrow:", rel);
  console.log("Bob balance (after):", await silk.balance("bob"));
}

run().catch(console.error);
