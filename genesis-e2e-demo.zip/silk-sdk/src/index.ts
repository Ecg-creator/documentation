
export class SilkClient {
  baseUrl: string;
  constructor(baseUrl: string = "http://localhost:4200") {
    this.baseUrl = baseUrl;
  }
  async balance(acct: string): Promise<number> {
    const r = await fetch(`${this.baseUrl}/balances/${acct}`);
    const j = await r.json();
    return j.balance ?? 0;
  }
  async createEscrow(id: string, from_acct: string, to_acct: string, amount: number) {
    const r = await fetch(`${this.baseUrl}/escrow/create`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({id, from_acct, to_acct, amount})
    });
    return r.json();
  }
  async releaseEscrow(id: string) {
    const r = await fetch(`${this.baseUrl}/escrow/release/${id}`, { method: "POST" });
    return r.json();
  }
}
