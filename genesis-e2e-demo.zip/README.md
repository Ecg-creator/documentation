
# Genesis E2E Demo (Warden + SILK SDK)

This bundle spins up two services and a minimal SDK so you can demo *Warden* (governance + compliance) alongside a mock *SILK* service (balances + escrow).

## Quickstart (Docker)

```bash
docker compose up --build
# Warden: http://localhost:4100/health
# SILK:   http://localhost:4200/health
```

### Try the policy gate
```bash
curl -s http://localhost:4100/policy/current | jq
curl -s -X POST http://localhost:4100/deploy/authorize \
  -H 'Content-Type: application/json' \
  -d '{
        "repo":"genesis/riveros",
        "branch":"main",
        "checks_passed":["build","unit_tests","codeql"],
        "approvals":2,
        "code_owner_review":true,
        "signatures":2
      }'
```

## SDK (TypeScript)

```bash
cd silk-sdk
npm install
npm run build
npm run demo
# Watch console for balances and escrow flow
```

## Helm (Kubernetes)

Build local images with tags first (or push to a registry) then:

```bash
helm install warden ./charts/warden --set image=warden-service --set tag=latest
helm install silk ./charts/silk --set image=silk-mock-service --set tag=latest
```

## Layout
- `warden-service/` — FastAPI service for policy + attestations + tenants
- `silk-mock-service/` — FastAPI mock for balances + escrow
- `silk-sdk/` — TypeScript client for SILK
- `charts/` — Helm charts for each service
- `docker-compose.yaml` — Local orchestration

## Next steps
- Replace in-memory stores with Postgres in `warden-service`
- Add real attestation format (e.g., DSSE/SLSA)
- Wire `/deploy/authorize` to CI (GitHub Actions status → Warden check)
- Swap `silk-mock-service` for real SILK service
