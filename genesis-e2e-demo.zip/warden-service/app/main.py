
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
from datetime import datetime

app = FastAPI(title="Warden Service", version="0.1.0")

# ---- In-memory stores (swap with DB later) ----
class Policy(BaseModel):
    version: str = "0.1.0"
    required_signatures: int = 2
    require_code_owner_review: bool = True
    required_checks: List[str] = ["build", "unit_tests", "codeql"]
    protected_branches: List[str] = ["main", "release/*"]
    allow_deletions: bool = False
    allow_force_push: bool = False

class Attestation(BaseModel):
    id: str
    subject: str
    verdict: str
    evidence: Dict = {}
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class Tenant(BaseModel):
    id: str
    name: str
    license: str
    region: str = "IN"
    compliance: Dict = {"esg": "pending", "gdpr": "n/a"}

POLICY = Policy()
ATTESTATIONS: Dict[str, Attestation] = {}
TENANTS: Dict[str, Tenant] = {}

# Seed a demo tenant
TENANTS["demo"] = Tenant(id="demo", name="Believers Commons — Demo Factory", license="ECG-DEMO-001")

@app.get("/health")
def health():
    return {"ok": True, "service": "warden", "time": datetime.utcnow().isoformat()}

@app.get("/policy/current", response_model=Policy)
def get_policy():
    return POLICY

@app.post("/policy/update", response_model=Policy)
def update_policy(p: Policy):
    global POLICY
    POLICY = p
    return POLICY

@app.post("/attestations", response_model=Attestation)
def post_attestation(a: Attestation):
    ATTESTATIONS[a.id] = a
    return a

@app.get("/attestations/{att_id}", response_model=Attestation)
def get_attestation(att_id: str):
    a = ATTESTATIONS.get(att_id)
    if not a:
        raise HTTPException(404, "Attestation not found")
    return a

class DeployRequest(BaseModel):
    repo: str
    branch: str
    checks_passed: List[str] = []
    approvals: int = 0
    code_owner_review: bool = False
    signatures: int = 0

@app.post("/deploy/authorize")
def deploy_authorize(req: DeployRequest):
    # Enforce simple policy
    if req.branch in POLICY.protected_branches or any(req.branch.startswith(p.replace("/*","/")) for p in POLICY.protected_branches if "/*" in p):
        missing_checks = [c for c in POLICY.required_checks if c not in req.checks_passed]
        if missing_checks:
            return {"authorized": False, "reason": f"Missing checks: {missing_checks}"}
        if req.approvals < 2:
            return {"authorized": False, "reason": "Not enough approvals"}
        if POLICY.require_code_owner_review and not req.code_owner_review:
            return {"authorized": False, "reason": "Code owner review required"}
        if req.signatures < POLICY.required_signatures:
            return {"authorized": False, "reason": "Insufficient signatures"}
    # If not protected or all satisfied
    return {"authorized": True, "reason": "Policy satisfied"}

@app.get("/tenants", response_model=List[Tenant])
def list_tenants():
    return list(TENANTS.values())

@app.get("/tenants/{tenant_id}", response_model=Tenant)
def get_tenant(tenant_id: str):
    t = TENANTS.get(tenant_id)
    if not t:
        raise HTTPException(404, "Tenant not found")
    return t

class ComplianceUpdate(BaseModel):
    compliance: Dict

@app.post("/tenants/{tenant_id}/compliance", response_model=Tenant)
def update_compliance(tenant_id: str, cu: ComplianceUpdate):
    t = TENANTS.get(tenant_id)
    if not t:
        raise HTTPException(404, "Tenant not found")
    t.compliance.update(cu.compliance)
    TENANTS[tenant_id] = t
    return t
