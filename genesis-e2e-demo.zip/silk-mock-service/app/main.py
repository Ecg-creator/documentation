
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict
from datetime import datetime

app = FastAPI(title="SILK Mock", version="0.1.0")

BALANCES: Dict[str, int] = {"alice": 1000, "bob": 500}
ESCROWS: Dict[str, Dict] = {}

class Escrow(BaseModel):
    id: str
    from_acct: str
    to_acct: str
    amount: int
    status: str = "created"

@app.get("/health")
def health():
    return {"ok": True, "service": "silk", "time": datetime.utcnow().isoformat()}

@app.get("/balances/{acct}")
def balance(acct: str):
    return {"account": acct, "balance": BALANCES.get(acct, 0)}

@app.post("/escrow/create")
def escrow_create(e: Escrow):
    if BALANCES.get(e.from_acct, 0) < e.amount:
        return {"ok": False, "reason": "insufficient funds"}
    BALANCES[e.from_acct] = BALANCES.get(e.from_acct, 0) - e.amount
    ESCROWS[e.id] = e.model_dump()
    return {"ok": True, "escrow": ESCROWS[e.id]}

@app.post("/escrow/release/{eid}")
def escrow_release(eid: str):
    e = ESCROWS.get(eid)
    if not e: return {"ok": False, "reason": "not found"}
    if e["status"] != "created": return {"ok": False, "reason": "already closed"}
    BALANCES[e["to_acct"]] = BALANCES.get(e["to_acct"], 0) + e["amount"]
    e["status"] = "released"
    ESCROWS[eid] = e
    return {"ok": True, "escrow": e}
