import 'dotenv/config';
import express from 'express';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';
import tenantsRouter from './routes/tenants.js';
import licensesRouter from './routes/licenses.js';

const app = express();
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'virtual-silk-road-hub', time: new Date().toISOString() });
});

app.use('/tenants', tenantsRouter);
app.use('/licenses', licensesRouter);

// Minimal not-found and error handlers
app.use((req, res) => {
  res.status(404).json({ error: 'Not found', path: req.path });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal error', details: String(err?.message || err) });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Hub backend listening on ${port}`));
