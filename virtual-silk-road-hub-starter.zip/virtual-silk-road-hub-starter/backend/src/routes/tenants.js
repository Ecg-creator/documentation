import express from 'express';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { getTenantCompliance } from '../services/wardenClient.js';

const router = express.Router();

async function db() {
  const sqlite = await open({ filename: process.env.DB_PATH || './db/dev.sqlite', driver: sqlite3.Database });
  return sqlite;
}

// List tenants
router.get('/', async (_req, res, next) => {
  try {
    const d = await db();
    const rows = await d.all('SELECT * FROM tenants ORDER BY created_at DESC');
    res.json(rows);
  } catch (e) { next(e); }
});

// Get tenant with compliance
router.get('/:id', async (req, res, next) => {
  try {
    const d = await db();
    const row = await d.get('SELECT * FROM tenants WHERE id = ?', req.params.id);
    if (!row) return res.status(404).json({ error: 'tenant not found' });
    let compliance = null;
    try { compliance = await getTenantCompliance(req.params.id); } catch(_e) {}
    res.json({ ...row, compliance });
  } catch (e) { next(e); }
});

// Create tenant (requires off-band compliance check; this endpoint only registers intent)
router.post('/', async (req, res, next) => {
  try {
    const { name, owner_contact, stack_type } = req.body || {};
    if (!name) return res.status(400).json({ error: 'name required' });
    const d = await db();
    const result = await d.run(
      'INSERT INTO tenants (name, owner_contact, stack_type, created_at) VALUES (?, ?, ?, datetime("now"))',
      name, owner_contact || null, stack_type || 'genesis-basic'
    );
    res.status(201).json({ id: result.lastID, name, owner_contact, stack_type });
  } catch (e) { next(e); }
});

export default router;
