import express from 'express';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { getPolicyHash, attestRepoAction } from '../services/wardenClient.js';

const router = express.Router();

async function db() {
  const sqlite = await open({ filename: process.env.DB_PATH || './db/dev.sqlite', driver: sqlite3.Database });
  return sqlite;
}

router.get('/', async (_req, res, next) => {
  try {
    const d = await db();
    const rows = await d.all('SELECT * FROM licenses ORDER BY issued_at DESC');
    res.json(rows);
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try {
    const { tenant_id, scope } = req.body || {};
    if (!tenant_id) return res.status(400).json({ error: 'tenant_id required' });
    const policy = await getPolicyHash(); // ensure we anchor issuance to the current policy hash
    const d = await db();
    const result = await d.run(
      'INSERT INTO licenses (tenant_id, scope, policy_hash, issued_at) VALUES (?, ?, ?, datetime("now"))',
      tenant_id, scope || 'standard', policy.hash
    );
    res.status(201).json({ id: result.lastID, tenant_id, scope: scope || 'standard', policy_hash: policy.hash });
  } catch (e) { next(e); }
});

// Example guarded action that would require an attestation
router.post('/attest', async (req, res, next) => {
  try {
    const out = await attestRepoAction(req.body || {});
    res.json(out);
  } catch (e) { next(e); }
});

export default router;
