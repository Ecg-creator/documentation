import fetch from 'node-fetch';

const WARDEN_URL = process.env.WARDEN_URL || 'http://localhost:4600';

export async function getPolicyHash() {
  const r = await fetch(`${WARDEN_URL}/policy/hash`);
  if (!r.ok) throw new Error(`Warden policy check failed ${r.status}`);
  return r.json();
}

export async function attestRepoAction(payload) {
  // payload: { actor, action, repo, branch, prId }
  const r = await fetch(`${WARDEN_URL}/attestations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!r.ok) throw new Error(`Warden attestation failed ${r.status}`);
  return r.json();
}

export async function getTenantCompliance(tenantId) {
  const r = await fetch(`${WARDEN_URL}/tenants/${tenantId}/compliance`);
  if (!r.ok) throw new Error(`Warden tenant compliance failed ${r.status}`);
  return r.json();
}
