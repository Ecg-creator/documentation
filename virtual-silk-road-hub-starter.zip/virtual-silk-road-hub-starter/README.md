# Virtual Silk Road Hub (Starter)

**Program of the Believers’ Commons** — this hub is the implementation arm that hosts tenant Genesis Stacks under Commons policy, surfaced through a public dashboard and an API.

- **Believers’ Commons** → owns the charter and licenses
- **Creators–Commons** → outreach & onboarding
- **Virtual Silk Road Hub** → this repo (policy-aware tenant & license registry)
- **Warden** → separate service that enforces policy and provides attestations
- **SILK** → contracts + SDK (separate repos)

## Monorepo Map (starter)
```
virtual-silk-road-hub/
├─ backend/              # Node/Express API
├─ frontend/             # React dashboard (Vite)
├─ api-specs/            # OpenAPI
├─ docs/                 # architecture notes
└─ .github/workflows/    # CI
```

## Quick Start

### Prereqs
- Node.js >= 18
- SQLite3 (for local dev) or Postgres if you prefer (swap driver)
- pnpm or npm

### Backend
```bash
cd backend
cp .env.example .env
pnpm install   # or: npm install
pnpm dev       # or: npm run dev
```
API boots on `http://localhost:4000`. See `/health`, `/tenants`, `/licenses`.

### Frontend
```bash
cd ../frontend
pnpm install   # or: npm install
pnpm dev
```
UI boots on `http://localhost:5173` (Vite).

### Institutional Nesting (how this repo fits)
```
Believers’ Commons (trust)
│
├─ governance/ (policy, rego, warden.json)     ← separate repo
├─ creators-commons/ (education & grants)      ← separate repo
├─ virtual-silk-road-hub/ (THIS REPO)          ← operational hub
└─ warden/ + silk-contracts/ + silk-sdk/       ← separate repos
```

This repo **never** bypasses the Warden. It only *reads/reflects* policy state via `WARDEN_URL` APIs and blocks actions that fail attestations.

## License
Apache-2.0 (change if your Commons charter requires).
