# Architecture (Starter)

## Institutional Nesting
- **Believers’ Commons (trust)**: holds charter, issues licenses, publishes policy.
- **Creators–Commons (program)**: onboarding & education.
- **Virtual Silk Road Hub (this repo)**: tenant & license registry with Warden-aware UI/API.
- **Warden (service)**: policy enforcement & attestations (separate repo).

## Data Flow (high-level)
1. Tenant requests onboarding via Hub.
2. Hub registers tenant intent in DB.
3. Warden evaluates compliance (telemetry, repo rules, signatures).
4. If compliant, license issued and anchored to current `policy_hash` from Warden.
5. Frontend shows status: **Compliant / Paused / Non-compliant**.

## Tables
- `tenants(id, name, owner_contact, stack_type, created_at)`
- `licenses(id, tenant_id, scope, policy_hash, issued_at)`

## API contracts
See `api-specs/openapi.yaml`.

## Deployment Notes
- Use Postgres + Prisma/Knex or stick with SQLite for dev.
- Configure `WARDEN_URL` to the enforcement service endpoint.
- Protect main branch via repo rules; require attestation step in CI/CD.
