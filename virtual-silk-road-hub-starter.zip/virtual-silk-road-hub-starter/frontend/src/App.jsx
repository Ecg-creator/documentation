import React, { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export default function App() {
  const [tenants, setTenants] = useState([])
  const [licenses, setLicenses] = useState([])
  const [health, setHealth] = useState(null)

  useEffect(() => {
    fetch(`${API}/health`).then(r => r.json()).then(setHealth).catch(()=>{})
    fetch(`${API}/tenants`).then(r => r.json()).then(setTenants).catch(()=>{})
    fetch(`${API}/licenses`).then(r => r.json()).then(setLicenses).catch(()=>{})
  }, [])

  return (
    <div style={{ padding: 24, fontFamily: 'system-ui, sans-serif' }}>
      <h1>Virtual Silk Road Hub</h1>
      <p><em>Program of the Believers’ Commons</em></p>
      <section>
        <h2>Status</h2>
        <pre>{JSON.stringify(health, null, 2)}</pre>
      </section>
      <section>
        <h2>Tenants</h2>
        <pre>{JSON.stringify(tenants, null, 2)}</pre>
      </section>
      <section>
        <h2>Licenses</h2>
        <pre>{JSON.stringify(licenses, null, 2)}</pre>
      </section>
      <footer style={{ marginTop: 32, opacity: 0.7 }}>
        <small>This hub reflects Warden policy; it does not bypass it.</small>
      </footer>
    </div>
  )
}
