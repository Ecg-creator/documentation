# Contributing

1. All PRs require:
   - 2 approvals
   - Passing status checks
   - Code scanning clean
   - Attestation from Warden (`/attestations/:prId`)

2. No force-push or non-fast-forward merges on protected branches.

3. Any schema change needs a migration plan and a rollback plan in the PR body.

4. Security issues → security@believerscommons.example (replace with real).