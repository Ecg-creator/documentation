
import os, sys, csv, json, time, random, argparse
import requests
from dotenv import load_dotenv

load_dotenv()
BASE = os.getenv("BASE_URL","http://localhost:8080")
TIMEOUT = int(os.getenv("TIMEOUT_SECONDS","15"))
AUDIT = os.path.join("out","audit_unified.jsonl")
os.makedirs("out", exist_ok=True)

def audit(kind, req, res):
    with open(AUDIT,"a",encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.time(), "kind": kind, "request": req, "response": res})+"\n")

def post(path, payload):
    url = f"{BASE}{path}"
    r = requests.post(url, json=payload, timeout=TIMEOUT)
    if not r.ok and r.status_code not in (200,201):
        raise SystemExit(f"POST {url} failed: {r.status_code} {r.text}")
    data = r.json() if r.text else {}
    audit(f"POST {path}", payload, data)
    return data

def pick(csv_path):
    rows = list(csv.DictReader(open(csv_path, encoding="utf-8")))
    return random.choice(rows)

def preregister(prefix):
    base = os.path.join("corridors", prefix, "data", "samples")
    for fname, ltype, idkey, numkey in [("warehouses.csv","warehouse","warehouse_id","license_number"),
                                        ("gins.csv","gin","gin_id","license_number"),
                                        ("labs.csv","lab","lab_id","nabl_number")]:
        for row in csv.DictReader(open(os.path.join(base,fname), encoding="utf-8")):
            payload = {"actorId": row[idkey], "licenseType": ltype, "licenseNumber": row[numkey], "validUntil": row.get("valid_until","2026-12-31"), "attachments":[]}
            post("/licenses", payload)

def seed_one(prefix, idx):
    base = os.path.join("corridors", prefix, "data", "samples")
    mill = pick(os.path.join(base,"mills.csv"))
    fpo  = pick(os.path.join(base,"fpos.csv"))
    lab  = pick(os.path.join(base,"labs.csv"))
    farmer = pick(os.path.join(base,"farmers.csv"))
    qty = random.choice([12,16,20,24,30])
    po_id = f"PO-{prefix}-{idx:04d}"
    escrow_per_bale = random.choice([22000,24000,25000,27000])
    claim = post("/claims", {"poId": po_id, "buyerId": mill["mill_id"], "sellerId": fpo["fpo_id"],
                             "items":[{"sku":"cotton-bale","qty":qty,"uom":"bale"}],
                             "metadata":{"corridor": prefix, "season":"2025-26"}})
    ctid = claim["claimTokenId"]
    post("/escrow/fund", {"claimTokenId":ctid, "bankAccountRef": mill["escrow_bank_ref"],
                          "amountINR": qty*escrow_per_bale, "currency":"INR"})
    staple = round(random.uniform(26.0, 30.0), 1)
    moisture = round(random.uniform(6.0, 8.5), 1)
    post("/qc/submit", {"claimTokenId":ctid, "labId": lab["lab_id"],
                        "reports":[{"test":"staple","value":staple,"units":"mm"},
                                   {"test":"moisture","value":moisture,"units":"%"}]})
    farmer_share = int(qty*escrow_per_bale*random.uniform(0.55,0.7))
    fpo_share    = qty*escrow_per_bale - farmer_share
    post("/settlement/release", {"claimTokenId": ctid,
                                 "beneficiaries":[{"id": farmer["farmer_id"], "amountINR": farmer_share},
                                                  {"id": fpo["fpo_id"], "amountINR": fpo_share}],
                                 "mspTopupINR": 0})
    return ctid

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pos", type=int, default=6, help="How many POs to seed in total")
    args = ap.parse_args()
    prefixes = ["TS","GJ","MH"]
    for p in prefixes: preregister(p)
    idx = 1
    for i in range(args.pos):
        p = prefixes[i % len(prefixes)]
        ctid = seed_one(p, idx)
        idx += 1
        print(f"[{p}] Seeded claimTokenId={ctid}")
    print("Unified seeding complete. See out/audit_unified.jsonl")
if __name__ == "__main__":
    main()
