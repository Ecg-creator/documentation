
import os, sys, time, argparse, random, subprocess
from dotenv import load_dotenv

load_dotenv()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pos", type=int, default=50, help="Total POs to seed")
    ap.add_argument("--burst", type=int, default=5, help="POs per burst")
    args = ap.parse_args()
    remaining = args.pos
    i = 0
    while remaining > 0:
        n = min(args.burst, remaining)
        subprocess.check_call([sys.executable, "scripts/unified_seeder.py", "--pos", str(n)])
        remaining -= n
        i += 1
        sleep_s = random.uniform(0.5, 2.0)
        print(f"Burst {i} complete. Sleeping {sleep_s:.1f}s...")
        time.sleep(sleep_s)
    print("Stress test complete.")
if __name__ == "__main__":
    main()
