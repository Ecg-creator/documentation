
import argparse, os, requests, json, time
from dotenv import load_dotenv
load_dotenv()
BASE = os.getenv("ADJUST_BASE_URL", "http://localhost:8081")
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--claimTokenId", required=True)
    ap.add_argument("--returned", type=int, required=True)
    ap.add_argument("--reason", required=True)
    ap.add_argument("--meta", default="{}", help="JSON metadata string")
    a = ap.parse_args()
    payload = {"claimTokenId": a.claimTokenId, "returned": a.returned, "reason": a.reason, "metadata": json.loads(a.meta)}
    r = requests.post(f"{BASE}/adjustments/create", json=payload, timeout=15)
    r.raise_for_status()
    data = r.json()
    print("Created adjustment:", data)
if __name__ == "__main__":
    main()
