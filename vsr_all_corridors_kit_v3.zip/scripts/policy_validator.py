
import os, sys, json, argparse, yaml, time
from datetime import datetime

def load_audit(path):
    evts = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            try:
                evts.append(json.loads(line))
            except:
                pass
    return evts

def ts(sec): 
    try: return float(sec)
    except: return time.time()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corridor", required=True, help="TS|GJ|MH")
    ap.add_argument("--audit", required=True, help="Path to audit JSONL (from v2 seeder)")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(os.path.join("corridors", args.corridor, "config.yaml"), encoding="utf-8"))
    qc_h = cfg["sla"]["qc_hours"]; settle_h = cfg["sla"]["settlement_hours"]

    evts = load_audit(args.audit)
    # Map claimTokenId -> times for claim, qc, settle
    timeline = {}
    for e in evts:
        k = e.get("kind","")
        req = e.get("request", {})
        res = e.get("response", {})
        t = ts(e.get("ts"))
        ctid = None
        if k.endswith("/claims"):
            ctid = res.get("claimTokenId")
            if ctid: timeline.setdefault(ctid, {})["claim_ts"] = t
        elif k.endswith("/qc/submit"):
            ctid = req.get("claimTokenId")
            if ctid: timeline.setdefault(ctid, {})["qc_ts"] = t
        elif k.endswith("/settlement/release"):
            ctid = req.get("claimTokenId")
            if ctid: timeline.setdefault(ctid, {})["settle_ts"] = t

    violations = []
    for ctid, tmap in timeline.items():
        ct = tmap.get("claim_ts"); qt = tmap.get("qc_ts"); st = tmap.get("settle_ts")
        if ct and qt:
            qc_hours = (qt - ct)/3600.0
            if qc_hours > qc_h + 0.01:
                violations.append((ctid, f"QC turnaround {qc_hours:.2f}h exceeds {qc_h}h"))
        if qt and st:
            settle_hours = (st - qt)/3600.0
            if settle_hours > settle_h + 0.01:
                violations.append((ctid, f"Settlement turnaround {settle_hours:.2f}h exceeds {settle_h}h"))

    if violations:
        print("SLA violations detected:")
        for v in violations:
            print("-", v[0], ":", v[1])
        sys.exit(1)
    print("Policy OK — no SLA violations observed in audit.")
if __name__ == "__main__":
    main()
