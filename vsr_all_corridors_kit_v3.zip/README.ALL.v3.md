
# VSR — All Corridors Kit (v3)
Adds three capabilities on top of v2:

1) **Adjustment-Claim mock endpoint** (`/adjustments/create`):
   - Creates a child Adjustment Claim referencing an original ClaimToken (for returns/shortages).
   - Stores minimal state in-memory and emits a JSONL audit.

2) **Oracle feed schemas** (+ examples):
   - `schemas/oracle.msp.schema.json` and `schemas/oracle.market.schema.json`
   - Example signed payloads under `oracle_examples/`

3) **Policy validator**:
   - `scripts/policy_validator.py` loads corridor `config.yaml`
   - Validates SLA settings and enforces them against seeder audit entries (best-effort using audit timestamps)
   - Fails with non-zero exit if violations are detected.

## Quick start

### 0) Prereq
- v2 kit seeded at least once so `out/audit_unified_v2.jsonl` exists.

### 1) Run the Adjustment server (separate microservice)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python extensions/adjustment_server.py  # serves http://localhost:8081
```

### 2) Create an adjustment for a returned quantity
```bash
python scripts/create_adjustment.py --claimTokenId <CTID> --returned 6 --reason "Buyer returned 6 bales due to contamination"
```

### 3) Validate policy (SLAs) across corridors
```bash
python scripts/policy_validator.py --corridor TS --audit ../vsr_all_corridors_kit_v2/out/audit_unified_v2.jsonl
```

---

> Note: This adjustment server is a thin demo service, separate from your v1 mock. In production, merge these endpoints into your main VSR API with persistent storage and signatures.
