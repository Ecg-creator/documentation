
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import time, json, os

APP = FastAPI(title="VSR Adjustment Demo", version="0.1.0")

STATE = {
    "adjustments": [],  # each: {adjId, claimTokenId, returned, reason, createdAt, metadata}
}

AUDIT_PATH = os.getenv("ADJUST_AUDIT", "out/audit_adjustments.jsonl")
os.makedirs(os.path.dirname(AUDIT_PATH), exist_ok=True)

class AdjustmentCreate(BaseModel):
    claimTokenId: str = Field(..., description="Original claim token id")
    returned: int = Field(..., ge=1, description="Returned quantity (bales)")
    reason: str
    metadata: Optional[Dict[str, Any]] = None

class Adjustment(BaseModel):
    adjId: str
    claimTokenId: str
    returned: int
    reason: str
    createdAt: float
    metadata: Dict[str, Any] = {}

def audit(kind: str, req: dict, res: dict):
    with open(AUDIT_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.time(), "kind": kind, "request": req, "response": res}) + "\n")

@APP.post("/adjustments/create", response_model=Adjustment)
def create_adjustment(payload: AdjustmentCreate):
    adjId = f"ADJ-{int(time.time()*1000)}"
    rec = Adjustment(adjId=adjId, claimTokenId=payload.claimTokenId, returned=payload.returned,
                     reason=payload.reason, createdAt=time.time(), metadata=payload.metadata or {})
    STATE["adjustments"].append(rec.dict())
    audit("ADJUSTMENT_CREATE", payload.dict(), rec.dict())
    return rec

@APP.get("/_debug/adjustments", response_model=List[Adjustment])
def list_adjustments():
    return [Adjustment(**a) for a in STATE["adjustments"]]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(APP, host="0.0.0.0", port=8081)
