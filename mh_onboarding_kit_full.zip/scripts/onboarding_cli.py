
import os, sys, csv, json, time
import requests
from dotenv import load_dotenv

load_dotenv()
BASE = os.getenv("BASE_URL","http://localhost:8080")
TIMEOUT = int(os.getenv("TIMEOUT_SECONDS","15"))
OUT_AUDIT = os.path.join("out","audit_trail.jsonl")
os.makedirs("out", exist_ok=True)

def audit(kind, payload, response):
    with open(OUT_AUDIT, "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.time(), "kind": kind, "request": payload, "response": response})+"\n")

def post(path, payload):
    url = f"{BASE}{path}"
    r = requests.post(url, json=payload, timeout=TIMEOUT)
    if not r.ok and r.status_code not in (200,201):
        raise SystemExit(f"POST {url} failed: {r.status_code} {r.text}")
    data = r.json() if r.text else {}
    audit(f"POST {path}", payload, data)
    return data

def register_licenses(samples_dir):
    print("== Registering licenses ==")
    for name, ltype, idkey, numkey in [("warehouses.csv","warehouse","warehouse_id","license_number"),
                                       ("gins.csv","gin","gin_id","license_number"),
                                       ("labs.csv","lab","lab_id","nabl_number")]:
        with open(os.path.join(samples_dir,name), newline='', encoding="utf-8") as f:
            for row in csv.DictReader(f):
                post("/licenses", {"actorId": row[idkey], "licenseType": ltype, "licenseNumber": row[numkey], "validUntil": row["valid_until"], "attachments":[]})

def seed_full_po(po_id, mill, fpo, qty_bales, lab_id, benes):
    claim = post("/claims", {"poId": po_id, "buyerId": mill["mill_id"], "sellerId": fpo["fpo_id"], "items":[{"sku":"cotton-bale","qty":qty_bales,"uom":"bale"}], "metadata":{"corridor":"Maharashtra","season":"2025-26"}})
    ctid = claim["claimTokenId"]
    post("/escrow/fund", {"claimTokenId":ctid,"bankAccountRef":mill["escrow_bank_ref"],"amountINR":qty_bales*25000,"currency":"INR"})
    post("/qc/submit", {"claimTokenId":ctid,"labId":lab_id,"reports":[{"test":"staple","value":28.5,"units":"mm"},{"test":"moisture","value":7.1,"units":"%"}]})
    post("/settlement/release", {"claimTokenId":ctid,"beneficiaries":benes,"mspTopupINR":0})
    return ctid

def seed_partial_po(po_root, mill, fpo, qty_bales_total, lab_id, farmer_id):
    half = qty_bales_total//2
    cta = seed_full_po(po_root+"-A", mill, fpo, half, lab_id, [{"id": farmer_id,"amountINR":half*25000*0.6}, {"id": fpo["fpo_id"],"amountINR":half*25000*0.4}])
    ctb = seed_full_po(po_root+"-B", mill, fpo, qty_bales_total-half, lab_id, [{"id": farmer_id,"amountINR":(qty_bales_total-half)*25000*0.6}, {"id": fpo["fpo_id"],"amountINR":(qty_bales_total-half)*25000*0.4}])
    return (cta, ctb)

def main():
    if len(sys.argv)<2:
        print("Usage: python scripts/onboarding_cli.py data/samples")
        sys.exit(2)
    samples_dir = sys.argv[1]
    register_licenses(samples_dir)
    mills = list(csv.DictReader(open(os.path.join(samples_dir,"mills.csv"), encoding="utf-8")))
    fpos = list(csv.DictReader(open(os.path.join(samples_dir,"fpos.csv"), encoding="utf-8")))
    labs = list(csv.DictReader(open(os.path.join(samples_dir,"labs.csv"), encoding="utf-8")))
    farmers = list(csv.DictReader(open(os.path.join(samples_dir,"farmers.csv"), encoding="utf-8")))
    seed_full_po("PO-MH-0001", mills[0], fpos[0], 24, labs[0]["lab_id"], [{"id": farmers[0]["farmer_id"],"amountINR":300000}, {"id": fpos[0]["fpo_id"],"amountINR":300000}])
    seed_partial_po("PO-MH-0002", mills[1], fpos[1], 30, labs[1]["lab_id"], farmers[1]["farmer_id"])
    print("All seed flows completed. See out/audit_trail.jsonl")
if __name__ == "__main__":
    main()
