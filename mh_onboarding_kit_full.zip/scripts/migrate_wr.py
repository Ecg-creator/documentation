print('Usage: python scripts/migrate_wr.py data/legacy/legacy_wr.csv out/licenses_wr.jsonl --post')
