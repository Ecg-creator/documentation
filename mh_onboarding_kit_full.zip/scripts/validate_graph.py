print('Usage: python scripts/validate_graph.py --graph-json ../silk_vsr_pilot_scaffold_max/silk_graph.json')
