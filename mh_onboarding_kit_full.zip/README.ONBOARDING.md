# Maharashtra Corridor — Onboarding & Data Migration Kit (Rich)

Run `make seed` after installing requirements; see out/audit_trail.jsonl.
